sayHello();

function sayHello() {
    console.log("Witaj świecie!");
}

const sayHello2 = function() {
    console.log("Cześć!");
};

sayHello2();

const sayHello3 = function hello() {
    console.log("Witam!");
};

sayHello3();

