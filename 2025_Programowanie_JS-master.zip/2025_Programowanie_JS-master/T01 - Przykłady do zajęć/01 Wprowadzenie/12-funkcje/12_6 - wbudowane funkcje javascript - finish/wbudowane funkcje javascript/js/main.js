console.log(isFinite(1000 * 1000));

const result = "Piotr" * 1000;

console.log(isNaN(result));

console.log(parseInt("20zł"));
console.log(parseFloat("20.50zł"));

console.log(Math.PI);
console.log(Math.min(100, 10, 5, 300));
