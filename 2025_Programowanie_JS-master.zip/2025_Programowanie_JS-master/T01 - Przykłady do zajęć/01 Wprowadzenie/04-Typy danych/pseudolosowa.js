/*
Losowo wybrane liczby
Na potrzeby ćwiczeń w początkowych rozdziałach książki musisz wiedzieć, jak w JavaScripcie można wygenerować
losowo wybraną liczbę. Nie ma żadnych powodów do zmartwień, jeśli nie rozumiesz przedstawionego tutaj polecenia.
W tym miejscu wystarczy wiedzieć, że służy ono do wygenerowania losowo wybranej liczby.
Math.random();
To polecenie można wydać w konsoli i od razu otrzymać wynik jego wykonania.
 */
console.log(Math.random());
console.log(Math.random() * 100);
console.log(Math.floor(Math.random() * 100));
