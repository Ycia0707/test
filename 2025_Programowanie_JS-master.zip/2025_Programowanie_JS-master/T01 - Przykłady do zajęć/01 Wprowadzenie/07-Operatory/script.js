// 1. Arithmetic Operators

let x;

x = 5 + 5;
x = 5 - 5;
x = 5 * 5;
x = 5 / 5;
x = 7 % 5;

// Konkatenacje
x = 'Hello' + ' ' + 'World';

// Potęgowanie
x = 2 ** 3;

// Inkrementacja
x = 1;
// x = x + 1;
x++;

// Dekrementacja
// x = x - 1;
x--;

// 2. Operatorzy przypisania

x = 10;

x += 5;
x -= 5;
x *= 5;
x /= 5;
x %= 5;
x **= 5;

// 3. Operatory porównania

// Równe (tylko wartość, nie typ)
x = 2 == '2';

// Równe (typ i wartość)
x = 2 === '2';

// Nierówne (tylko wartość, nie typ)
x = 2 != '2';

// Nierówne (Typ i wartość)
x = 2 !== 2;

// Większy niż i mniejszy niż
x = 10 > 5;
x = 10 < 5;
x = 10 <= 5;
x = 10 >= 5;

console.log(x);
