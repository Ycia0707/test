let x;

// Pierwiastek kwadratowy
x = Math.sqrt(9);

// Wartość bezwzględna
x = Math.abs(-5);

// Zaokrąglenie
x = Math.round(4.2);

// Zaokrąglenie w górę
x = Math.ceil(4.2);

// Zaokrąglenie w dół
x = Math.floor(4.9);

// Pierwiastek
x = Math.pow(2, 3);

// Minimum
x = Math.min(4, 5, 3);

// Maksimum
x = Math.max(4, 5, 3);

// Liczba pseudolosowa między 0 i 1
x = Math.random();

// Liczba losowa od 1 do 100
x = Math.floor(Math.random() * 100 + 1);

console.log(x);
