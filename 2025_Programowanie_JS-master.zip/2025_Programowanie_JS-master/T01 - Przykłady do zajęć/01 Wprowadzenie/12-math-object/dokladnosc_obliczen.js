
let x;
x = 0.1 * 5;
x = 0.15 * 3;
x = 0.1 + 0.2;

// IEEE 754
console.log(x)

/*
Mirosław Zelent o dokładności obliczeń w JS
https://www.youtube.com/watch?v=tiK92m-RopI&t=95s

*/
