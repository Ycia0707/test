// console.log('Witaj Świecie')
// console.warn('Teraz zwróć uwagę')
// console.error('To jest bardzo poważny Błąd!!!!')
// let tabela1={imie:"Tomasz",nazwisko:"Nowak",wiek:"23"}
// let tabela2 = [12,5,33,45,123,'rower',null,'end'];
// console.table(tabela1)
// console.table(tabela2)
console.group('pojedyncza')
console.log('Witaj Świecie')
console.warn('Teraz zwróć uwagę')
console.error('To jest bardzo poważny Błąd!!!!')
console.groupEnd()