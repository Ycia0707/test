//Przykład 3.15
let liczby = [10, 23, 57, 94, 32];