// przyklad 3.50
let  tekst = "Obiekty języka JavaScript";
let dlug = tekst.length;

console.log(dlug);