//Przykład 3.13
let k = true;