//3.63
// var Tablica= new Array('Anna','Adam','Piotr');
let Tablica = ['Anna','Adam','Piotr']
console.log(Tablica.join());
console.table(Tablica);
Tablica.reverse()
console.log(Tablica.join());