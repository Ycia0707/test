//Przykład 3.4
document.write("<a href='https://zspglogow.pl'>Hiperłącze do strony dołączone za pomocą skryptu</a>");