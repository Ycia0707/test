// Przyklad 3.81
var link1 = links[0].href;