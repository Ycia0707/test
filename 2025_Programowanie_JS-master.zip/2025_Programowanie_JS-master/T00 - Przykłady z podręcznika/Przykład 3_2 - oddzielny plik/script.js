//Przykład 3.4
document.write("Napisz program w języku JavaScript");