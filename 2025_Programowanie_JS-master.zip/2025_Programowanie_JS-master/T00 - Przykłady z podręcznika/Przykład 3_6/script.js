//przyklad 3_6
let i = 30;
document.write("Zmienna i ma wartość "+ i +"<br>");