//Przykład 3.74
window.setInterval("mojCzas()", 1000);