//przyklad 3.65
var Tablica = new Array(3000, 4567, 12459, 406745);
Tablica.sort();
document.write(Tablica.join());