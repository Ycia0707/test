//3.5
document.write(201);
document.write(0o10)
// Popatrz na wyświetloną liczbę
// Skąd się wzięła 8 na końcu