// Przykład 3.55
var tx1 = 'komputer';
document.write(tx1.duzaLitera());