// Przykład 3.7
let a, b, c; // deklaracja zmiennych
a = 4; b = 9; // przypisanie wartości
c = a + b; // wyrażenie

document.write(a + " " + typeof(a) + "<br>" )
document.write(b + " " + typeof(b)  + "<br>")
document.write(c + " " + typeof(c)  + "<br>")