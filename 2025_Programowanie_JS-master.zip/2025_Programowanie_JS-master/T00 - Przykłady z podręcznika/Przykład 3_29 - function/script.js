//Przykład 3.29
function suma(a, b) {
    let c = a + b;
    return c;
}