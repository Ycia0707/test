//przyklad 3.12
let a = "Warszawa";
let b = 'Kraków';