//Przykład 3.14
let osoba = {nazwisko: "Nowak", imie: "Paweł", wiek: 18};
