//Przykład 3.28
for (let i = 0; i <= 30; i++){
    if ((i % 3) !== 0){
        continue;
    }
    document.write(i + "; ");
}