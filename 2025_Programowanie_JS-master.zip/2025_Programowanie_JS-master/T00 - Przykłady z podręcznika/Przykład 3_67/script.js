// Przykład 3.67
var data = new Date();