//przyklad 3.72
window.setTimeout(function() {
    alert("Uwaga!!!");
}, 1000);