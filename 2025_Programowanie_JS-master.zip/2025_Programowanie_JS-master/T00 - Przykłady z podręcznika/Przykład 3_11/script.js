//Przykład 3.11
let a = 12;
let b = 0o37;
let c = 0xACB;
let d = 0.12e-2;